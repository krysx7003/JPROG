package Zadanie_2;

import java.awt.EventQueue;

public class Zad7 {

    public static void main(String[] args){
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Frame();
            }
        });


    }
    //wysokość wykresu to największa zaznaczona liczba
    //przerysowanie po naciśnięciu ENTER albo
    //
}
